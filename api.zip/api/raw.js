export default function handler(req, res) {
  // Daftar token whitelist:
  const whitelist = [
    "TOKEN_BOT_1",
    "TOKEN_BOT_2",
    "TOKEN_BOT_3"
  ];

  // Kirim response JSON
  res.status(200).json(whitelist);
}